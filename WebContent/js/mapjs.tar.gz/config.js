var mapserverUrl="maptile";
var map=null;
var arcgismap=null;
var googlemap=null;
var layer_ditu="EMap";

var mapserverurls=["http://127.0.0.1:8080/maptile"];
var limittiles_num=80;
//var defaultmap="google";8
/**
,"http://192.168.2.141:8080/mapCache/maptile",
    "http://192.168.2.141:5000/mapCache/maptile","http://192.168.2.141:5001/mapCache/maptile",
    "http://192.168.2.114:8000/mapCache/maptile","http://192.168.2.114:5000/mapCache/maptile"
    **/