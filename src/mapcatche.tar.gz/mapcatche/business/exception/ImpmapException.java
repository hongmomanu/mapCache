package mapcatche.business.exception;

public class ImpmapException extends Exception{

	public ImpmapException(String msg){
		 super(msg);     //调用父类的构造方法
	}
}
